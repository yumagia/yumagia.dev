//CSCI 5607 HW 2 - Image Conversion Instructor: S. J. Guy <sjguy@umn.edu>
//In this assignment you will load and convert between various image formats.
//Additionally, you will manipulate the stored image data by quantizing, cropping, and suppressing channels

#include "image.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>

#include <fstream>
using namespace std;

// Math macros
#define Box(x, r) ((abs(x) < 1) ? 1 / (2 * r) : 0)
#define Tent(x) ((abs(x) < 1) ? 1 - abs(x) : 0)
#define Gaussian(x) (exp(0 - ((x) * (x))))

#define KernelSampleInclusive(i, n) (((1.0 / (n / 2)) * i) - 1)
#define KernelSampleExclusive(i, n) ((1 - (2 / (n + 1.0))) * (((1.0 / (n / 2)) * i) - 1))

#define Vec2Dist(x, y) (sqrtf(((x) * (x)) + ((y) * (y))))
// TODO:
//#define BSplineCubic(x) ()


/**
 * Image
 **/
Image::Image (int width_, int height_){

    assert(width_ > 0);
    assert(height_ > 0);

    width           = width_;
    height          = height_;
    num_pixels      = width * height;
    sampling_method = IMAGE_SAMPLING_POINT;
    
    data.raw = new uint8_t[num_pixels*4];
		int b = 0; //which byte to write to
		for (int j = 0; j < height; j++){
			for (int i = 0; i < width; i++){
				data.raw[b++] = 0;
				data.raw[b++] = 0;
				data.raw[b++] = 0;
				data.raw[b++] = 0;
			}
		}

    assert(data.raw != NULL);
}

Image::Image(const Image& src){
	width           = src.width;
	height          = src.height;
	num_pixels      = width * height;
	sampling_method = IMAGE_SAMPLING_POINT;
	
	data.raw = new uint8_t[num_pixels*sizeof(Pixel)];
	
	memcpy(data.raw, src.data.raw, num_pixels*sizeof(Pixel));
}

Image::Image(char* fname){

	int numComponents; //(e.g., Y, YA, RGB, or RGBA)

	//Load the pixels with STB Image Lib
	uint8_t* loadedPixels = stbi_load(fname, &width, &height, &numComponents, 4);
	if (loadedPixels == NULL){
		printf("Error loading image: %s", fname);
		exit(-1);
	}

	//Set image member variables
	num_pixels = width * height;
	sampling_method = IMAGE_SAMPLING_POINT;

  //Copy the loaded pixels into the image data structure
	data.raw = new uint8_t[num_pixels*sizeof(Pixel)];
	memcpy(data.raw, loadedPixels, num_pixels*sizeof(Pixel));
	free(loadedPixels);
}

Image::~Image(){
    delete[] data.raw;
    data.raw = NULL;
}

void Image::Write(char* fname){
	
	int lastc = strlen(fname);

	switch (fname[lastc-1]){
	   case 'g': //jpeg (or jpg) or png
	     if (fname[lastc-2] == 'p' || fname[lastc-2] == 'e') //jpeg or jpg
	        stbi_write_jpg(fname, width, height, 4, data.raw, 95);  //95% jpeg quality
	     else //png
	        stbi_write_png(fname, width, height, 4, data.raw, width*4);
	     break;
	   case 'a': //tga (targa)
	     stbi_write_tga(fname, width, height, 4, data.raw);
	     break;
	   case 'p': //bmp
	   default:
	     stbi_write_bmp(fname, width, height, 4, data.raw);
	}
}


void Image::Brighten (double factor){
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			Pixel scaled_p = p*factor;
			GetPixel(x,y) = scaled_p;
		}
	}
}

void Image::ExtractChannel(int channel){
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			GetPixel(x, y) = p * Pixel((channel == 0) ? 1 : 0, (channel == 1) ? 1 : 0, (channel == 2) ? 1 : 0);
		}
	}
}


void Image::Quantize (int nbits){
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			GetPixel(x, y) = PixelQuant(p, nbits);
		}
	}
}

Image* Image::Crop(int x, int y, int w, int h){
   int   nx, ny;
   Image *image = new Image(w, h);

   nx = x;
	for (nx; nx < (x + w); nx++) {
      ny = y;
      for (ny; ny < (y + h); ny++) {
         (*image).GetPixel(nx - x, ny - y) = GetPixel(nx, ny);
      }
   }
   
	return image;
}


// Misnomer, should really be called "apply noise", because
// it does not actually *add* noise, rather, it lerps with random pixels.
// The range is 0-1
void Image::AddNoise (double factor){
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			GetPixel(x, y) = PixelLerp(p, PixelRandom(), factor);
		}
	}
}

void Image::ChangeContrast (double factor){
	int x,y;
	double l;

	l = 0;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			l += p.Luminance();
		}
	}

	l /= Width() * Height();
	Pixel mean_l = Pixel(l, l, l);

	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			Pixel contrasted_p = PixelLerp(mean_l, p, factor);

			GetPixel(x, y) = contrasted_p;
		}
	}
}


void Image::ChangeSaturation(double factor){
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			Component l = p.Luminance();
			Pixel gray_p = Pixel(l, l, l);
			Pixel contrasted_p = PixelLerp(gray_p, p, factor);

			GetPixel(x, y) = contrasted_p;
		}
	}
}


//For full credit, check that your dithers aren't making the pictures systematically brighter or darker
void Image::RandomDither (int nbits){
	int x,y;
	float r, g, b;
	double l, rand_l;

	// l = 0;
	// for (x = 0 ; x < Width() ; x++){
	// 	for (y = 0 ; y < Height() ; y++){
	// 		Pixel p = GetPixel(x, y);
	// 		l += p.Luminance();
	// 	}
	// }
	// l /= Width() * Height();
	// printf("%f\n", l);

	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			Pixel rand_p = PixelRandom() * (0.5);
			r = p.r + (rand_p.r/255.0 - p.r/255.0) * rand_p.r;
			g = p.g + (rand_p.g/255.0 - p.g/255.0) * rand_p.g;
			b = p.b + (rand_p.b/255.0 - p.b/255.0) * rand_p.b;

			GetPixel(x, y) = PixelQuant(Pixel(r, g, b), nbits);
		}
	}

	// l = 0;
	// for (x = 0 ; x < Width() ; x++){
	// 	for (y = 0 ; y < Height() ; y++){
	// 		Pixel p = GetPixel(x, y);
	// 		l += p.Luminance();
	// 	}
	// }
	// l /= Width() * Height();

	// printf("%f\n", l);
}

//This bayer method gives the quantization thresholds for an ordered dither.
//This is a 4x4 dither pattern, assumes the values are quantized to 16 levels.
//You can either expand this to a larger bayer pattern. Or (more likely), scale
//the threshold based on the target quantization levels.
static int Bayer4[4][4] ={
    {15,  7, 13,  5},
    { 3, 11,  1,  9},
    {12,  4, 14,  6},
    { 0,  8,  2, 10}
};


void Image::OrderedDither(int nbits){
	/* WORK HERE  (Extra Credit) */
}

/* Error-diffusion parameters */
const double
    ALPHA = 7.0 / 16.0,
    BETA  = 3.0 / 16.0,
    GAMMA = 5.0 / 16.0,
    DELTA = 1.0 / 16.0;

void Image::FloydSteinbergDither(int nbits){
	int x, y;
	int pixel_x, pixel_y;
	int r, g, b;
	Pixel p;

	for (y = 0 ; y < Height() ; y++){
		for (x = 0 ; x < Width() ; x++){
			// Find quantization error and set the new pixel
			Pixel orig_pixel = GetPixel(x, y);
			Pixel quantized_pixel = PixelQuant(orig_pixel, nbits);
			GetPixel(x, y) = quantized_pixel;
			
			r = orig_pixel.r - quantized_pixel.r;
			g = orig_pixel.g - quantized_pixel.g;
			b = orig_pixel.b - quantized_pixel.b;


			// Alpha
			pixel_x = x + 1;
			pixel_y = y;

			if (pixel_x < Width()) {
				p = GetPixel(pixel_x, pixel_y);
				GetPixel(pixel_x, pixel_y) = Pixel(ComponentClamp(p.r + r * ALPHA), ComponentClamp(p.g + g * ALPHA), ComponentClamp(p.b + b * ALPHA));
			}

			// Beta
			pixel_x = x - 1;
			pixel_y = y + 1;

			if (pixel_x >= 0 && pixel_y < Height()) {
			p = GetPixel(pixel_x, pixel_y);
			GetPixel(pixel_x, pixel_y) = Pixel(ComponentClamp(p.r + r * BETA), ComponentClamp(p.g + g * BETA), ComponentClamp(p.b + b * BETA));
			}

			// Gamma 
			pixel_x = x;
			pixel_y = y + 1;

			if (pixel_y < Height()) {
				p = GetPixel(pixel_x, pixel_y);
				GetPixel(pixel_x, pixel_y) = Pixel(ComponentClamp(p.r + r * GAMMA), ComponentClamp(p.g + g * GAMMA), ComponentClamp(p.b + b * GAMMA));
			}

			// Delta
			pixel_x = x + 1;
			pixel_y = y + 1;
			if (pixel_x < Width() && pixel_y < Height()) {
			p = GetPixel(pixel_x, pixel_y);
			GetPixel(pixel_x, pixel_y) = Pixel(ComponentClamp(p.r + r * DELTA), ComponentClamp(p.g + g * DELTA), ComponentClamp(p.b + b * DELTA));
			}
		}
	}
}

// Gaussian blur with size nxn filter
void Image::Blur(int n){
	float r, g, b; 							//You'll get better results converting everything to floats, then converting back to bytes (less quantization error)
	Image* img_copy = new Image(*this); 	//This is will copying the image, so you can read the original values for filtering
	float kern[n][n];
	int i, j;
	float gaussian_sample_i, gaussian_sample_j;
	float sum;

	sum = 0;
	for(j = 0; j < n; j++) {
		gaussian_sample_i = Gaussian(2 * KernelSampleExclusive(i, n));
		for(i = 0; i < n; i++) {
			gaussian_sample_j = Gaussian(2 * KernelSampleExclusive(j, n));
			kern[j][i] = gaussian_sample_i * gaussian_sample_j;
			sum += kern[j][i];
			//printf("%i %f\n", j * i * n, kern[j][i]);
		}
	}

	float scale = 1 / sum;
	
	for(j = 0; j < n; j++) {
		for(i = 0; i < n; i++) {
			kern[j][i] *= scale;
		}
	}

	int x,y;
	int pixel_x, pixel_y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			r = 0;
			g = 0;
			b = 0;

			for(j = 0; j < n; j++) {
				for(i = 0; i < n; i++) {
					pixel_x = x + (i - n / 2);
					pixel_y = y + (j - n / 2);

					pixel_x = (pixel_x >= 0) ? pixel_x : 0;
					pixel_x = (pixel_x <= Width() - 1) ? pixel_x : Width() - 1;

					pixel_y = (pixel_y >= 0) ? pixel_y : 0;
					pixel_y = (pixel_y <= Height() - 1) ? pixel_y : Height() - 1;

					//printf("%i %i %i %i\n", pixel_x, pixel_y, Width(), Height());
					Pixel p = (*img_copy).GetPixel(pixel_x, pixel_y);

					r += p.r * kern[j][i];
					g += p.g * kern[j][i];
					b += p.b * kern[j][i];
				}
			}

			GetPixel(x , y) = Pixel(r, g, b);

		}
	}

	delete img_copy;
}

void Image::Sharpen(int n){
	int x, y;

	Image* img_copy = new Image(*this);

	(*img_copy).Blur(n);

	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			Pixel blur_p = (*img_copy).GetPixel(x, y);
			Pixel sharpened_p = PixelLerp(p, blur_p, -1);

			GetPixel(x, y) = sharpened_p;
		}
	}

	delete img_copy;
}

static int Sobel_x[3][3] ={
    {-1,  0,  1},
    {-2,  0,  2},
    {-1,  0,  1}
};

static int Sobel_y[3][3] ={
    {-1,  -2,  -1},
    {0,  0,  0},
    {1,  2,  1}
};


// Uses Sobel operator
void Image::EdgeDetect(){
	float r, g, b; //You'll get better results converting everything to floats, then converting back to bytes (less quantization error)
	int r_sobel_x, g_sobel_x, b_sobel_x;
	int r_sobel_y, g_sobel_y, b_sobel_y;	
	Image* img_copy = new Image(*this); //This is will copying the image, so you can read the original values for filtering

	int x,y;
	int pixel_x, pixel_y;
	int i, j;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			r_sobel_x = g_sobel_x = b_sobel_x = 0;
			r_sobel_y = g_sobel_y = b_sobel_y = 0;
			
			for (j = 0; j < 3; j++) {
				for (i = 0; i < 3; i++) {
					pixel_x = x + i - 1;
					pixel_y = y + j - 1;

					pixel_x = (pixel_x >= 0) ? pixel_x : 0;
					pixel_x = (pixel_x <= Width() - 1) ? pixel_x : Width() - 1;

					pixel_y = (pixel_y >= 0) ? pixel_y : 0;
					pixel_y = (pixel_y <= Height() - 1) ? pixel_y : Height() - 1;

					//printf("%i %i %i %i\n", pixel_x, pixel_y, Width(), Height());
					Pixel p = (*img_copy).GetPixel(pixel_x, pixel_y);

					r_sobel_x += p.r * Sobel_x[j][i];
					g_sobel_x += p.g * Sobel_x[j][i];
					b_sobel_x += p.b * Sobel_x[j][i];

					r_sobel_y += p.r * Sobel_y[j][i];
					g_sobel_y += p.g * Sobel_y[j][i];
					b_sobel_y += p.b * Sobel_y[j][i];
				}
			}

			r = Vec2Dist(r_sobel_x, r_sobel_y);
			g = Vec2Dist(g_sobel_x, g_sobel_y);
			b = Vec2Dist(b_sobel_x, b_sobel_y);

			GetPixel(x, y) = Pixel(r, g, b);

		}
	}

	delete img_copy;

}

Image* Image::Scale(double sx, double sy){
	Image* scaled_image = new Image(Width() * sx, Height() * sy);

	int x,y;
	float u, v;
	for (x = 0 ; x < (*scaled_image).Width() ; x++){
		for (y = 0 ; y < (*scaled_image).Height() ; y++){
			u = x / sx;
			v = y / sy;

			(*scaled_image).GetPixel(x, y) = Sample(u, v);
		}
	}
	return scaled_image;
}

Image* Image::Rotate(double angle){
	Image* rotated_image = new Image(Width(), Height());

	int x,y;
	float u, v;
	for (x = 0 ; x < (*rotated_image).Width() ; x++){
		for (y = 0 ; y < (*rotated_image).Height() ; y++){
			u = (x - Width()/2) * cos(-angle) - (y - Height()/2) * sin(-angle);
			v = (x - Width()/2) * sin(-angle) + (y - Height()/2) * cos(-angle);

			(*rotated_image).GetPixel(x, y) = Sample(u + Width()/2, v + Height()/2);
		}
	}

	return rotated_image;
}

void Image::Fun(){
	/* WORK HERE */
}

/**
 * Image Sample
 **/
void Image::SetSamplingMethod(int method){
   assert((method >= 0) && (method < IMAGE_N_SAMPLING_METHODS));
   sampling_method = method;
}


Pixel Image::Sample (double u, double v){
	float r, g, b;
	Pixel sample;

	if(u < 0 || v < 0 || u >= Width() || v >= Height()) {
		return Pixel(0, 0, 0);
	}

	if (sampling_method == IMAGE_SAMPLING_POINT) {
		int iu = trunc(u + 0.5);
		int iv = trunc(v + 0.5);
		iu = ((iu > Width() - 1) ? Width() - 1 : iu);
		iv = ((iv > Height() - 1) ? Height() - 1 : iv);
		
		sample = GetPixel(iu, iv);
   } else if (sampling_method == IMAGE_SAMPLING_BILINEAR) {
		int tu = trunc(u);
		int tv = trunc(v);
		int tu_next = ((tu + 1 < Width()) ? tu + 1 : tu);
		int tv_next = ((tv + 1 < Height()) ? tv + 1 : tv);
		Pixel q11 = GetPixel(tu, tv);
		Pixel q21 = GetPixel(tu_next, tv);
		Pixel q12 = GetPixel(tu, tv_next);
		Pixel q22 = GetPixel(tu_next, tv_next);

		Pixel y1 = PixelLerp(q11, q21, u - tu);
		Pixel y2 = PixelLerp(q12, q22, u - tu);

		sample = PixelLerp(y1, y2, v - tv);
   } else if (sampling_method == IMAGE_SAMPLING_GAUSSIAN) {
		int tu = trunc(u);
		int tv = trunc(v);
		int extent_size = 5; // How big of a square area we want to collect pixels from
	
		

		int x_max = tu + extent_size;
		x_max = ((x_max < Width()) ? x_max : Width());

		int y_max = tv + extent_size;
		y_max = ((y_max < Height()) ? y_max : Height());

		float r = g = b = 0;
		double gaussian_sum = 0; 

		int i = tu - extent_size;
		i = ((i > 0) ? i : 0);
		for (i = i; i < x_max; i++) {
			int j = tv - extent_size;
			j = ((j > 0) ? j : 0);
			for (j = j; j < y_max; j++) {
				Pixel sub_sample = GetPixel(i, j);
				double gaussian_value = Gaussian(Vec2Dist(u - i, v - j));
				r += (double) sub_sample.r * gaussian_value;
				g += (double) sub_sample.g * gaussian_value;
				b += (double) sub_sample.b * gaussian_value;
				gaussian_sum += gaussian_value;
			}
		}

		sample = Pixel(r / gaussian_sum, g / gaussian_sum, b / gaussian_sum);
   }
   return sample;
}