//UMN CSCI 5607 2D Geometry Library Homework [HW0]
//TODO: For the 18 functions below, replace their sub function with a working version that matches the desciption.

#ifndef GEOM_LIB_H
#define GEOM_LIB_H

#include "pga.h"

//Displace a point p on the direction d
//The result is a point
Point2D move(Point2D p, Dir2D d){
  return Point2D(p.x + d.x, p.y + d.y);
}

//Compute the displacement vector between points p1 and p2
//The result is a direction 
Dir2D displacement(Point2D p1, Point2D p2){
  return Dir2D(p2.x - p1.x, p2.y - p1.y); //Wrong, fix me...
}

//Compute the distance between points p1 and p2
//The result is a scalar 
float dist(Point2D p1, Point2D p2){
  return Dir2D(p2.x - p1.x, p2.y - p1.y).magnitude();
}

//Compute the perpendicular distance from the point p the the line l
//The result is a scalar 
float dist(Line2D l, Point2D p){
  return (MultiVector(l).normalized()).vee(MultiVector(p).normalized()).s;
}

//Compute the perpendicular distance from the point p the the line l
//The result is a scalar 
float dist(Point2D p, Line2D l){
  return (MultiVector(p).normalized()).vee(MultiVector(l).normalized()).s;
}

//Compute the intersection point between lines l1 and l2
//You may assume the lines are not parallel
//The results is a a point that lies on both lines
Point2D intersect(Line2D l1, Line2D l2){
  return Point2D(MultiVector(l1).wedge(MultiVector(l2))); 
}

//Compute the line that goes through the points p1 and p2
//The result is a line 
Line2D join(Point2D p1, Point2D p2){
  return (MultiVector(p1).normalized()).vee(MultiVector(p2).normalized());
}

//Compute the projection of the point p onto line l
//The result is the closest point to p that lies on line l
Point2D project(Point2D p, Line2D l){
  return (MultiVector(l).dot(MultiVector(p))).times(MultiVector(l));
}

//Compute the projection of the line l onto point p
//The result is a line that lies on point p in the same direction of l
Line2D project(Line2D l, Point2D p){
  return (MultiVector(l).dot(MultiVector(p))).times(MultiVector(p)); 
}

//Compute the angle point between lines l1 and l2 in radians
//You may assume the lines are not parallel
//The results is a scalar
float angle(Line2D l1, Line2D l2){
  return acos((MultiVector(l1).normalized().dot(MultiVector(l2).normalized())).s);
}

//Compute if the line segment p1->p2 intersects the line segment a->b
//The result is a boolean
bool segmentSegmentIntersect(Point2D p1, Point2D p2, Point2D a, Point2D b){
  Line2D ab, p1p2;
  
  p1p2 = join(p1, p2);
  ab = join(a, b);
  if (dist(p1, ab) * dist(p2, ab) > 0) {
    return false;
  }
  if (dist(a, p1p2) * dist(b, p1p2) > 0) {
    return false;
  }
  return true;
}

//Compute if the point p lies inside the triangle t1,t2,t3
//Your code should work for both clockwise and counterclockwise windings
//The result is a bool
bool pointInTriangle(Point2D p, Point2D t1, Point2D t2, Point2D t3){
  Line2D e1, e2, e3;
  float dist1, dist2, dist3;

  e1 = join(t1, t2);
  e2 = join(t2, t3);
  e3 = join(t3, t1);
  dist1 = dist(p, e1);
  dist2 = dist(p, e2);
  dist3 = dist(p, e3);
  if ((dist1 * dist2 > 0) && (dist2 * dist3 > 0) && (dist3 * dist1 > 0)) {
    return true;
  }
  return false;
}

//Compute the area of the triangle t1,t2,t3
//The result is a scalar
float areaTriangle(Point2D t1, Point2D t2, Point2D t3){
  return MultiVector(t1).normalized().vee(MultiVector(t2).normalized().vee(MultiVector(t3).normalized())).s * 0.5; 
}

//Compute the distance from the point p to the triangle t1,t2,t3 as defined 
//by it's distance from the edge closest to p.
//The result is a scalar
//NOTE: There are some tricky cases to consider here that do not show up in the test cases!
float pointTriangleEdgeDist(Point2D p, Point2D t1, Point2D t2, Point2D t3){
  Line2D e1, e2, e3, re1, re2, re3;
  float dist1, dist2, dist3;
  float c1, c2, c3;
  float min;
  int cornerflag;
  Line2D majorbisector;

  e1 = join(t1, t2);
  e2 = join(t2, t3);
  e3 = join(t3, t1);
  re1 = join(t2, t1);
  re2 = join(t3, t2);
  re3 = join(t1, t3);
  dist1 = min = dist(p, e1);
  dist2 = dist(p, e2);
  dist3 = dist(p, e3);
  
  min = fabs(min);
  if (fabs(dist2) < min) {
    min = fabs(dist2);
  }
  if (fabs(dist3) < min) {
    min = fabs(dist3);
  }


  return min;
}

//Compute the distance from the point p to the closest of three corners of
// the triangle t1,t2,t3
//The result is a scalar
float pointTriangleCornerDist(Point2D p, Point2D t1, Point2D t2, Point2D t3){
  float dist1, dist2, dist3;
  float min;

  dist1 = min = dist(p, t1);
  dist2 = dist(p, t2);
  dist3 = dist(p, t3);
  if (dist2 < min) {
    min = dist2;
  }
  if (dist3 < min) {
    min = dist3;
  }
  return min; 
}

//Compute if the quad (p1,p2,p3,p4) is convex.
//Your code should work for both clockwise and counterclockwise windings
//The result is a boolean
bool isConvex_Quad(Point2D p1, Point2D p2, Point2D p3, Point2D p4){
  Line2D e1, e2, e3, e4;
  float de1, de2, de3, de4;

  e1 = join(p1, p2);
  e2 = join(p2, p3);
  e3 = join(p3, p4); 
  e4 = join(p4, p1);

  de1 = dist(p3, e1);
  de2 = dist(p4, e2);
  de3 = dist(p1, e3);
  de4 = dist(p2, e4);
  
  // if (de1 * dist(p4, e1) < 0) {    // Is any of this even faster?
  //   return false;
  // }
  // if (de2 * dist(p1, e2) < 0) {
  //   return false;
  // }
  // if (de3 * dist(p2, e3) < 0) {
  //   return false;
  // }
  // if (de4 * dist(p3, e4) < 0) {
  //   return false;
  // }

  if ((de1 * de2 > 0) && (de2 * de3 > 0) && (de3 * de4 > 0) && (de4 * de1 > 0)) {
    return true;
  }

  return false;
}

//Compute the reflection of the point p about the line l
//The result is a point
Point2D reflect(Point2D p, Line2D l){
  return Point2D(MultiVector(p).transform(MultiVector(l))); 
}

//Compute the reflection of the line d about the line l
//The result is a line
Line2D reflect(Line2D d, Line2D l){
  return Line2D(MultiVector(d).transform(MultiVector(l))); //Wrong, fix me...
}

#endif